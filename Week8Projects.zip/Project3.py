Python 3.14.3 (tags/v3.14.3:323c59a, Feb  3 2026, 16:04:56) [MSC v.1944 64 bit (AMD64)] on win32
Enter "help" below or click "Help" above for more information.
>>> 
... def isSorted(lst):
...     """Returns True if the list is sorted in ascending order,
...     otherwise returns False."""
...     
...     if len(lst) < 2:
...         return True
... 
...     for i in range(len(lst) - 1):
...         if lst[i] > lst[i + 1]:
...             return False
... 
...     return True
... 
>>> def main():
...     test_lists = [
...         [],
...         [5],
...         [1, 2, 3, 4],
...         [1, 2, 2, 3],
...         [3, 2, 1],
...         [1, 3, 2]
...     ]
... 
...     for lst in test_lists:
...         print(lst, "->", isSorted(lst))
... 
...         
>>> if __name__ == "__main__":
...     main()
... 
...     
[] -> True
[5] -> True
[1, 2, 3, 4] -> True
[1, 2, 2, 3] -> True
[3, 2, 1] -> False
[1, 3, 2] -> False

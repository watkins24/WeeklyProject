Python 3.14.3 (tags/v3.14.3:323c59a, Feb  3 2026, 16:04:56) [MSC v.1944 64 bit (AMD64)] on win32
Enter "help" below or click "Help" above for more information.
>>> def inputFloat(prompt):
...     """Prompts the user for a floating-point number.
...     Allows digits and at most one decimal point."""
...     
...     while True:
...         user_input = input(prompt)
... 
...         # Check that all characters are digits or decimal point
...         if user_input.count('.') <= 1 and all(
...             ch.isdigit() or ch == '.' for ch in user_input
...         ) and user_input != '.' and user_input != '':
...             
...             return float(user_input)
... 
...         else:
...             print("Invalid input. Please enter a valid floating-point number.")
... 
...             
>>> def main():
...     number = inputFloat("Enter a floating-point number: ")
...     print("You entered:", number)
... 
>>> if __name__ == "__main__":
...     main()
... 
...     
Enter a floating-point number: 41
You entered: 41.0

import math

def drawCircle(t, x, y, radius):
    """Draws a circle with center (x, y) and the given radius."""

    t.up()
    t.goto(x, y - radius)
    t.setheading(0)
    t.down()

    distance = 2.0 * math.pi * radius / 120.0

    for count in range(120):
        t.forward(distance)
        t.left(3)



        

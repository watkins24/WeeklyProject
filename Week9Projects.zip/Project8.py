from images import Image

def grayscale(image):
    """Converts the image to grayscale."""
    for y in range(image.getHeight()):
        for x in range(image.getWidth()):
            p = image.getPixel(x, y)

            red = p[0]
            green = p[1]
            blue = p[2]

            avg = (red + green + blue) // 3

            image.setPixel(x, y, (avg, avg, avg))



def sepia(image):
    """Converts a color image to sepia."""

    grayscale(image)

    for y in range(image.getHeight()):
        for x in range(image.getWidth()):
            p = image.getPixel(x, y)

            red = p[0]
            green = p[1]
            blue = p[2]

            if red < 63:
                red = int(red * 1.1)
                blue = int(blue * 0.9)
            elif red < 192:
                red = int(red * 1.15)
                blue = int(blue * 0.85)
            else:
                red = min(int(red * 1.08), 255)
                blue = int(blue * 0.93)

            image.setPixel(x, y, (red, green, blue))
